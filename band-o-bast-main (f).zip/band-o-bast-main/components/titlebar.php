<nav class="col navbar navbar-dark bg-dark navbar-expand-sm" style="height: 70px;">    
    <div class="container-fluid">
        <h1 class="navbar-brand">
            <img src="images/embleam.png" alt="Website Logo" class="mx-3 mt-1" style="width: 30px;">
            Band-O-Bast System
        </h1>
  </div>
</nav>